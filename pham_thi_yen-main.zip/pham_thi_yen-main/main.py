from watermarklab.benchmark import main

if __name__ == "__main__":
    main()
